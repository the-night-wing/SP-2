'use strict';

//exports.ordersGetAll