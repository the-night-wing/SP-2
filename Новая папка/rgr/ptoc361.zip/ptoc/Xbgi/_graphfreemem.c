/*
 * $Id: _graphfreemem.c,v 0.1 1993/12/09 23:59:27 king Exp king $
 * User hook into graphics memory deallocation.
 *
 * $Log: _graphfreemem.c,v $
 * Revision 0.1  1993/12/09  23:59:27  king
 * Initial version.  __graphfreemem not currently implemented.
 *
 */
#include "graphics.h"

void _graphfreemem(void *ptr, unsigned int size)
{
/*
 * This routine not currently implemented.
 */
}
