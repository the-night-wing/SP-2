/*
 * $Id: installuserfont.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Loads a font file that is not built into the BGI system.
 *
 * $Log: installuserfont.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

int installuserfont(char *name)
{
/*
 * This routine not currently implemented.
 */
    return 0;
}
